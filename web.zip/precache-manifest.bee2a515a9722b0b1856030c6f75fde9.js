self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d73ba2f424363f7a179ca770ad3ad023",
    "url": "/index.html"
  },
  {
    "revision": "3f2f5a998d6b125e8e7f",
    "url": "/static/css/2.80f479d8.chunk.css"
  },
  {
    "revision": "3f2f5a998d6b125e8e7f",
    "url": "/static/js/2.38ee5b74.chunk.js"
  },
  {
    "revision": "17addde56dada538fe1bc33d341e4ae4",
    "url": "/static/js/2.38ee5b74.chunk.js.LICENSE.txt"
  },
  {
    "revision": "aaf0bca98150664a31a5",
    "url": "/static/js/main.854c5786.chunk.js"
  },
  {
    "revision": "4e0e34f265fae8f33b01b27ae29d9d6f",
    "url": "/static/js/main.854c5786.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d6c8c24b05b094ee0f6f",
    "url": "/static/js/runtime-main.a72885c7.js"
  }
]);